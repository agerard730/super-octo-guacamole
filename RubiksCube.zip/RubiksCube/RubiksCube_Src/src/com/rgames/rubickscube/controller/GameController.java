package com.rgames.rubickscube.controller;

import com.rgames.rubickscube.model.GameModel;
import com.rgames.rubickscube.view.GameView;

/**
 */
public final class GameController {

    public GameController(final GameModel model, final GameView view) {
        
    }
    
}
