package com.rgames.rubickscube.model.game;

/**
 */
public final class Game {

}
