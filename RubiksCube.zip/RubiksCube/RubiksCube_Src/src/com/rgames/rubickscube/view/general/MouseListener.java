package com.rgames.rubickscube.view.general;

/**
 */
public class MouseListener implements IMouseListener {

    public MouseListener() {
        
    }
    
    public void mouseMoved(final int mouseX, final int mouseY) {
        
    }
    
    public void mouseUp(final int mouseX, final int mouseY) {
        
    }

    public void mouseDown(final int mouseX, final int mouseY) {
        
    }
    
}
