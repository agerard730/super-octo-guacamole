package test.gamelogic;

import com.rgames.rubickscube.model.cube.RubicksCube;

import junit.framework.TestCase;

/**
 */
public final class TestCube1 extends TestCase {

    public void test1() {
        
        final RubicksCube cube = new RubicksCube();
        assertNotNull(cube);
        
    }
    
}
